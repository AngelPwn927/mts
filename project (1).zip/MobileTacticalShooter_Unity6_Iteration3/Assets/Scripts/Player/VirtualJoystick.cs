using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

// Восстановлено: в Iteration3 архиве класс отсутствовал, но PlayerMovementAdvanced.cs на него ссылается.
public class VirtualJoystick : MonoBehaviour, IDragHandler, IPointerDownHandler, IPointerUpHandler
{
    [SerializeField] private RectTransform background;
    [SerializeField] private RectTransform handle;
    [SerializeField] private float handleRange = 80f;

    public Vector2 Value { get; private set; }

    private void Awake()
    {
        if (!background) background = (RectTransform)transform;
    }

    public void OnPointerDown(PointerEventData eventData) => OnDrag(eventData);

    public void OnDrag(PointerEventData eventData)
    {
        Vector2 local;

        if (!RectTransformUtility.ScreenPointToLocalPointInRectangle(
                background,
                eventData.position,
                eventData.pressEventCamera,
                out local))
            return;

        local = Vector2.ClampMagnitude(local, handleRange);

        if (handle)
            handle.anchoredPosition = local;

        Value = local / handleRange;
    }

    public void OnPointerUp(PointerEventData eventData)
    {
        Value = Vector2.zero;

        if (handle)
            handle.anchoredPosition = Vector2.zero;
    }
}
