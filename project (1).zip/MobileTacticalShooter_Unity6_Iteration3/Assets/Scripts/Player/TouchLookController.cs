using UnityEngine;
using UnityEngine.EventSystems;

// Обзор на мобильных: свайп по правой части экрана вращает тело (yaw) и камеру (pitch).
// В редакторе — правая кнопка мыши.
public class TouchLookController : MonoBehaviour
{
    [SerializeField] private Transform body;
    [SerializeField] private float touchSensitivity = .18f;
    [SerializeField] private float minPitch = -75f;
    [SerializeField] private float maxPitch = 75f;
    [SerializeField] private float lookZoneStartX = .35f; // левее — зона джойстика

    private float sensitivity = 1f;
    private float pitch;

    private void Start()
    {
        sensitivity = Mathf.Max(.1f, PlayerPrefs.GetFloat("Sensitivity", 1f));
    }

    private void Update()
    {
        HandleTouch();

#if UNITY_EDITOR || UNITY_STANDALONE
        HandleMouse();
#endif
    }

    private void HandleTouch()
    {
        for (int i = 0; i < Input.touchCount; i++)
        {
            Touch touch = Input.GetTouch(i);

            if (touch.phase != TouchPhase.Moved) continue;
            if (EventSystem.current &&
                EventSystem.current.IsPointerOverGameObject(touch.fingerId))
                continue;
            if (touch.position.x < Screen.width * lookZoneStartX)
                continue;

            float delta = touchSensitivity * sensitivity;
            Rotate(touch.deltaPosition.x * delta, -touch.deltaPosition.y * delta);
        }
    }

#if UNITY_EDITOR || UNITY_STANDALONE
    private void HandleMouse()
    {
        if (!Input.GetMouseButton(1)) return;
        if (EventSystem.current &&
            EventSystem.current.IsPointerOverGameObject())
            return;

        float delta = 3f * sensitivity;
        Rotate(Input.GetAxis("Mouse X") * delta,
               -Input.GetAxis("Mouse Y") * delta);
    }
#endif

    private void Rotate(float yaw, float pitchDelta)
    {
        if (!body)
            body = transform.root;

        body.Rotate(0f, yaw, 0f);

        pitch = Mathf.Clamp(pitch + pitchDelta, minPitch, maxPitch);
        transform.localEulerAngles = new Vector3(pitch, 0f, 0f);
    }
}
