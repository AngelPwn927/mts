using UnityEngine;

public class FootstepController : MonoBehaviour
{
    [SerializeField] private CharacterController controller;
    [SerializeField] private AudioSource source;
    [SerializeField] private AudioClip[] clips;
    [SerializeField] private float stepDistance = 2f;

    private Vector3 lastPosition;
    private float distance;

    private void Start()
    {
        lastPosition = transform.position;
    }

    private void Update()
    {
        if (!controller || !controller.isGrounded) return;

        float moved = Vector3.Distance(
            transform.position,
            lastPosition);

        lastPosition = transform.position;

        if (moved <= 0.001f) return;

        distance += moved;

        if (distance >= stepDistance)
        {
            distance = 0f;
            PlayStep();
        }
    }

    private void PlayStep()
    {
        if (!source || clips == null || clips.Length == 0)
            return;

        source.PlayOneShot(
            clips[Random.Range(0, clips.Length)]);
    }
}
