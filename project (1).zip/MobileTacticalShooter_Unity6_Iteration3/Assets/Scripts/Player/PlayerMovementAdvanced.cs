using UnityEngine;

[RequireComponent(typeof(CharacterController))]
public class PlayerMovementAdvanced : MonoBehaviour
{
    [SerializeField] private CharacterController controller;
    [SerializeField] private VirtualJoystick joystick;
    [SerializeField] private float walkSpeed = 5f;
    [SerializeField] private float sprintSpeed = 7f;
    [SerializeField] private float crouchSpeed = 2.5f;
    [SerializeField] private float acceleration = 18f;
    [SerializeField] private float gravity = -22f;
    [SerializeField] private float jumpHeight = 1.2f;

    private Vector3 velocity;
    private Vector3 planarVelocity;
    private bool sprint;
    private bool crouch;

    private void Reset() => controller = GetComponent<CharacterController>();

    private void Update()
    {
        Vector2 input = joystick ? joystick.Value : Vector2.zero;

        Vector3 wish =
            transform.right * input.x +
            transform.forward * input.y;

        float speed = crouch ? crouchSpeed : sprint ? sprintSpeed : walkSpeed;
        Vector3 target = wish * speed;

        planarVelocity = Vector3.MoveTowards(
            planarVelocity,
            target,
            acceleration * Time.deltaTime);

        controller.Move(planarVelocity * Time.deltaTime);

        if (controller.isGrounded && velocity.y < 0)
            velocity.y = -2f;

        velocity.y += gravity * Time.deltaTime;
        controller.Move(velocity * Time.deltaTime);
    }

    public void SetSprint(bool value) => sprint = value;
    public void ToggleCrouch() => crouch = !crouch;

    public void Jump()
    {
        if (!controller.isGrounded || crouch) return;
        velocity.y = Mathf.Sqrt(jumpHeight * -2f * gravity);
    }
}
