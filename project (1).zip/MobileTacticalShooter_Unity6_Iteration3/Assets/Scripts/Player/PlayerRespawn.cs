using UnityEngine;

public class PlayerRespawn : MonoBehaviour
{
    [SerializeField] private Transform spawnPoint;
    [SerializeField] private CharacterController controller;

    public void TeleportToSpawn()
    {
        Vector3 position = spawnPoint
            ? spawnPoint.position
            : transform.position + Vector3.up * .1f;

        // CharacterController нужно выключить на время телепорта
        if (controller) controller.enabled = false;
        transform.position = position;
        if (controller) controller.enabled = true;
    }
}
