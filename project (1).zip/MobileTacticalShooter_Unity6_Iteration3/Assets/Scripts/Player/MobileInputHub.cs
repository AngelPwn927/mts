using UnityEngine;

// Связывает экранные кнопки с оружием, гранатами и движением игрока.
public class MobileInputHub : MonoBehaviour
{
    [SerializeField] private PlayerMovementAdvanced movement;
    [SerializeField] private Weapon weapon;
    [SerializeField] private GrenadeController grenade;
    [SerializeField] private CameraRecoil cameraRecoil;

    private GameObject owner;
    private bool firing;

    private void Awake()
    {
        owner = gameObject;
    }

    private void Update()
    {
        if (!firing || !weapon || !weapon.enabled) return;

        if (weapon.TryFire(owner) && cameraRecoil && weapon.Data)
            cameraRecoil.AddRecoil(
                weapon.Data.recoilPitch,
                weapon.Data.recoilYaw);
    }

    // Вызывается с кнопки FIRE (PointerDown / PointerUp — автоогонь при удержании)
    public void SetFiring(bool value) => firing = value;

    public void Reload()
    {
        if (weapon)
            StartCoroutine(weapon.Reload());
    }

    public void ThrowGrenade()
    {
        if (grenade)
            grenade.Throw();
    }

    public void Jump()
    {
        if (movement)
            movement.Jump();
    }

    public void SetSprint(bool value)
    {
        if (movement)
            movement.SetSprint(value);
    }

    public void ToggleCrouch()
    {
        if (movement)
            movement.ToggleCrouch();
    }
}
