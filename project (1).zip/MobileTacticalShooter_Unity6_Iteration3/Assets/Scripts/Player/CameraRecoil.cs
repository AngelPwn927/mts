using UnityEngine;

public class CameraRecoil : MonoBehaviour
{
    [SerializeField] private float returnSpeed = 12f;
    [SerializeField] private float snappiness = 20f;

    private Vector3 current;
    private Vector3 target;

    public void AddRecoil(float pitch, float yaw)
    {
        target += new Vector3(-pitch, Random.Range(-yaw, yaw), 0);
    }

    private void LateUpdate()
    {
        target = Vector3.Lerp(target, Vector3.zero,
            returnSpeed * Time.deltaTime);

        current = Vector3.Lerp(
            current,
            target,
            snappiness * Time.deltaTime);

        transform.localRotation = Quaternion.Euler(current);
    }
}
