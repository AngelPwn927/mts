using UnityEngine;

public class DamageableHitbox : MonoBehaviour
{
    public enum HitZone { Body, Head, Legs }

    [SerializeField] private HitZone zone = HitZone.Body;
    [SerializeField] private Health owner;
    [SerializeField] private float multiplier = 1f;

    public HitZone Zone => zone;
    public Health Owner => owner;

    public void ApplyDamage(float baseDamage, GameObject attacker, float headMultiplier)
    {
        if (!owner || owner.IsDead) return;

        float finalMultiplier = zone switch
        {
            HitZone.Head => headMultiplier,
            HitZone.Legs => .75f,
            _ => multiplier
        };

        owner.TakeDamage(baseDamage * finalMultiplier, attacker);
    }
}
