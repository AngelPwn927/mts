using UnityEngine;

public class GrenadeController : MonoBehaviour
{
    [SerializeField] private ProjectileGrenade grenadePrefab;
    [SerializeField] private Transform throwPoint;
    [SerializeField] private float throwForce = 14f;

    public void Throw()
    {
        if (!grenadePrefab || !throwPoint) return;

        ProjectileGrenade grenade =
            Instantiate(grenadePrefab,
                throwPoint.position,
                throwPoint.rotation);

        grenade.Launch(
            throwPoint.forward * throwForce +
            Vector3.up * 2f,
            gameObject);
    }
}
