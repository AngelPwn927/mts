using UnityEngine;

[RequireComponent(typeof(Health))]
public class Armor : MonoBehaviour
{
    [SerializeField, Range(0f, .8f)]
    private float damageReduction = .25f;

    public float Absorb(float damage)
    {
        return damage * (1f - damageReduction);
    }
}
