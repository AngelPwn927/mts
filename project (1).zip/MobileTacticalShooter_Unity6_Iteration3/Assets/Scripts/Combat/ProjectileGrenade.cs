using UnityEngine;
using System.Collections;

public class ProjectileGrenade : MonoBehaviour
{
    [SerializeField] private Rigidbody body;
    [SerializeField] private float fuse = 2.5f;
    [SerializeField] private float radius = 5f;
    [SerializeField] private float damage = 80f;
    [SerializeField] private LayerMask hitMask = ~0;
    [SerializeField] private ParticleSystem explosionFx;

    private GameObject owner;

    public void Launch(Vector3 velocity, GameObject grenadeOwner)
    {
        owner = grenadeOwner;
        if (body) body.linearVelocity = velocity;
        StartCoroutine(Fuse());
    }

    private IEnumerator Fuse()
    {
        yield return new WaitForSeconds(fuse);
        Explode();
    }

    private void Explode()
    {
        if (explosionFx)
            Instantiate(explosionFx, transform.position, Quaternion.identity);

        Collider[] hits = Physics.OverlapSphere(
            transform.position, radius, hitMask,
            QueryTriggerInteraction.Ignore);

        foreach (Collider hit in hits)
        {
            Health health = hit.GetComponentInParent<Health>();
            if (!health || health.gameObject == owner || health.IsDead)
                continue;

            float distance = Vector3.Distance(
                transform.position,
                health.transform.position);

            float falloff = Mathf.Clamp01(1f - distance / radius);
            health.TakeDamage(damage * falloff, owner);
        }

        Destroy(gameObject);
    }
}
