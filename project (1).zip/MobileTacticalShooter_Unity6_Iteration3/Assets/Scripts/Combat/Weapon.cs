using UnityEngine;
using System.Collections;

public class Weapon : MonoBehaviour
{
    [SerializeField] private WeaponData data;
    [SerializeField] private Camera playerCamera;
    [SerializeField] private Transform muzzle;
    [SerializeField] private ParticleSystem muzzleFx;
    [SerializeField] private Animator animator;
    [SerializeField] private Transform recoilPivot;
    [SerializeField] private AudioClip fireClip;
    [SerializeField] private AudioClip emptyClip;
    [SerializeField] private AudioSource audioSource;

    public WeaponData Data => data;
    public int Ammo { get; private set; }
    public int ReserveAmmo { get; private set; }
    public bool IsReloading { get; private set; }
    public bool IsAiming { get; private set; }

    private float nextShotTime;
    private float recoilPitch;
    private float recoilYaw;

    private void Awake()
    {
        if (!playerCamera) playerCamera = Camera.main;
        if (data) ResetAmmo();
    }

    public void SetData(WeaponData newData)
    {
        data = newData;
        ResetAmmo();
    }

    public void ResetAmmo()
    {
        if (!data) return;
        Ammo = data.magazineSize;
        ReserveAmmo = data.magazineSize * 3;
    }

    public void SetAiming(bool value) => IsAiming = value;

    public bool TryFire(GameObject owner)
    {
        if (!data || IsReloading || Time.time < nextShotTime) return false;

        if (Ammo <= 0)
        {
            if (audioSource && emptyClip) audioSource.PlayOneShot(emptyClip);
            nextShotTime = Time.time + .15f;
            return false;
        }

        nextShotTime = Time.time + 1f / Mathf.Max(.01f, data.fireRate);
        Ammo--;

        if (animator) animator.SetTrigger("Fire");
        if (muzzleFx) muzzleFx.Play();
        if (audioSource && fireClip) audioSource.PlayOneShot(fireClip);

        ApplyRecoil();

        Vector3 direction = playerCamera.transform.forward;
        float spread = IsAiming ? data.aimSpread : data.hipSpread;
        direction = ApplySpread(direction, spread);

        Ray ray = new Ray(playerCamera.transform.position, direction);

        if (Physics.Raycast(ray, out RaycastHit hit, data.range, data.hitMask,
            QueryTriggerInteraction.Ignore))
        {
            DamageableHitbox hitbox =
                hit.collider.GetComponent<DamageableHitbox>();

            if (hitbox)
            {
                hitbox.ApplyDamage(data.damage, owner, data.headshotMultiplier);
            }
            else
            {
                Health target =
                    hit.collider.GetComponentInParent<Health>();

                if (target && target.gameObject != owner)
                    target.TakeDamage(data.damage, owner);
            }
        }

        return true;
    }

    private Vector3 ApplySpread(Vector3 direction, float degrees)
    {
        if (degrees <= 0f) return direction;

        Quaternion spread = Quaternion.Euler(
            Random.Range(-degrees, degrees),
            Random.Range(-degrees, degrees),
            0f);

        return spread * direction;
    }

    private void ApplyRecoil()
    {
        if (!recoilPivot || !data) return;

        recoilPitch += data.recoilPitch;
        recoilYaw += Random.Range(-data.recoilYaw, data.recoilYaw);

        recoilPivot.localRotation *=
            Quaternion.Euler(-recoilPitch, recoilYaw, 0f);

        recoilPitch *= .45f;
        recoilYaw *= .45f;
    }

    public IEnumerator Reload()
    {
        if (!data || IsReloading ||
            Ammo >= data.magazineSize ||
            ReserveAmmo <= 0)
            yield break;

        IsReloading = true;

        if (animator)
            animator.SetTrigger("Reload");

        yield return new WaitForSeconds(data.reloadTime);

        int needed = data.magazineSize - Ammo;
        int loaded = Mathf.Min(needed, ReserveAmmo);

        Ammo += loaded;
        ReserveAmmo -= loaded;

        IsReloading = false;
    }
}
