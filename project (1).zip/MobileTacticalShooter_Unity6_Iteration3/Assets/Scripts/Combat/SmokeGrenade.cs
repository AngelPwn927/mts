using UnityEngine;
using System.Collections;

public class SmokeGrenade : MonoBehaviour
{
    [SerializeField] private ParticleSystem smokeFx;
    [SerializeField] private float duration = 12f;
    [SerializeField] private float radius = 6f;

    private void Start()
    {
        if (smokeFx) smokeFx.Play();
        StartCoroutine(Lifetime());
    }

    private IEnumerator Lifetime()
    {
        yield return new WaitForSeconds(duration);
        Destroy(gameObject);
    }

    private void OnDrawGizmosSelected()
    {
        Gizmos.DrawWireSphere(transform.position, radius);
    }
}
