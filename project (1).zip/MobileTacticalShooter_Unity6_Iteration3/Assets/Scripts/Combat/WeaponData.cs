using UnityEngine;

// Восстановлено: в Iteration3 архиве класс отсутствовал, но Weapon.cs на него ссылается.
[CreateAssetMenu(fileName = "WeaponData", menuName = "TacticalShooter/Weapon Data")]
public class WeaponData : ScriptableObject
{
    [Header("Ballistics")]
    public float damage = 24f;
    public float fireRate = 9f;              // выстрелов в секунду
    public float range = 120f;
    public LayerMask hitMask = ~0;
    public float headshotMultiplier = 2f;

    [Header("Spread (degrees)")]
    public float hipSpread = 2.5f;
    public float aimSpread = .6f;

    [Header("Magazine")]
    public int magazineSize = 30;
    public float reloadTime = 1.8f;

    [Header("Recoil")]
    public float recoilPitch = 1.1f;
    public float recoilYaw = .5f;
}
