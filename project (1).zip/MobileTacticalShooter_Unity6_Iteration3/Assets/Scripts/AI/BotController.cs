using UnityEngine;
using UnityEngine.AI;
using System.Collections;

[RequireComponent(typeof(NavMeshAgent))]
public class BotController : MonoBehaviour
{
    private enum State { Patrol, Investigate, Chase, Attack, Dead }

    [SerializeField] private NavMeshAgent agent;
    [SerializeField] private Weapon weapon;
    [SerializeField] private Transform eye;
    [SerializeField] private Health health;

    [Header("Vision")]
    [SerializeField] private float detectionDistance = 35f;
    [SerializeField] private float attackDistance = 24f;
    [SerializeField] private float loseTargetDistance = 45f;
    [SerializeField] private float viewAngle = 110f;
    [SerializeField] private LayerMask visibilityMask = ~0;

    [Header("Movement")]
    [SerializeField] private float patrolRadius = 18f;
    [SerializeField] private float thinkInterval = .15f;
    [SerializeField] private float strafeInterval = 1.2f;

    private State state = State.Patrol;
    private Transform player;
    private Vector3 lastKnownPosition;
    private float nextThink;
    private float nextStrafe;
    private int strafeDirection = 1;

    private void Awake()
    {
        if (!agent) agent = GetComponent<NavMeshAgent>();
        if (!health) health = GetComponent<Health>();
        health.Died += OnDied;
    }

    private void Start()
    {
        GameObject p = GameObject.FindGameObjectWithTag("Player");
        if (p) player = p.transform;
        PickPatrolPoint();
    }

    private void Update()
    {
        if (state == State.Dead || !player || Time.time < nextThink)
            return;

        nextThink = Time.time + thinkInterval;

        float distance = Vector3.Distance(transform.position, player.position);
        bool visible = CanSeePlayer();

        if (visible)
            lastKnownPosition = player.position;

        if (visible && distance <= attackDistance)
            state = State.Attack;
        else if (visible && distance <= detectionDistance)
            state = State.Chase;
        else if (state == State.Chase || state == State.Attack)
            state = State.Investigate;

        switch (state)
        {
            case State.Patrol:
                if (!agent.pathPending &&
                    agent.remainingDistance < 1.5f)
                    PickPatrolPoint();
                break;

            case State.Investigate:
                agent.isStopped = false;
                agent.SetDestination(lastKnownPosition);

                if (!agent.pathPending &&
                    agent.remainingDistance < 2f)
                    state = State.Patrol;
                break;

            case State.Chase:
                agent.isStopped = false;
                agent.SetDestination(player.position);
                break;

            case State.Attack:
                agent.isStopped = true;
                FacePlayer();
                Strafe();
                if (weapon) weapon.TryFire(gameObject);
                break;
        }

        if (distance > loseTargetDistance &&
            state != State.Attack)
            state = State.Investigate;
    }

    private bool CanSeePlayer()
    {
        Vector3 origin = eye
            ? eye.position
            : transform.position + Vector3.up * 1.5f;

        Vector3 target =
            player.position + Vector3.up * 1.1f;

        Vector3 dir = target - origin;

        if (dir.sqrMagnitude >
            detectionDistance * detectionDistance)
            return false;

        float angle =
            Vector3.Angle(transform.forward, dir);

        if (angle > viewAngle * .5f)
            return false;

        if (Physics.Raycast(
            origin,
            dir.normalized,
            out RaycastHit hit,
            detectionDistance,
            visibilityMask,
            QueryTriggerInteraction.Ignore))
        {
            return hit.transform.root.CompareTag("Player");
        }

        return false;
    }

    private void Strafe()
    {
        if (Time.time >= nextStrafe)
        {
            nextStrafe = Time.time + strafeInterval;
            strafeDirection =
                Random.value > .5f ? 1 : -1;
        }

        Vector3 destination =
            transform.position +
            transform.right * strafeDirection * 1.5f;

        if (NavMesh.SamplePosition(
            destination,
            out NavMeshHit hit,
            2f,
            NavMesh.AllAreas))
        {
            agent.SetDestination(hit.position);
        }
    }

    private void FacePlayer()
    {
        Vector3 flat =
            player.position - transform.position;

        flat.y = 0;

        if (flat.sqrMagnitude > .01f)
        {
            transform.rotation =
                Quaternion.Slerp(
                    transform.rotation,
                    Quaternion.LookRotation(flat),
                    .25f);
        }
    }

    private void PickPatrolPoint()
    {
        Vector3 random =
            transform.position +
            Random.insideUnitSphere * patrolRadius;

        random.y = transform.position.y;

        if (NavMesh.SamplePosition(
            random,
            out NavMeshHit hit,
            patrolRadius,
            NavMesh.AllAreas))
        {
            agent.isStopped = false;
            agent.SetDestination(hit.position);
        }
    }

    private void OnDied(DamageInfo info)
    {
        state = State.Dead;
        agent.isStopped = true;

        if (weapon)
            weapon.enabled = false;

        StartCoroutine(DeathRoutine());
    }

    private IEnumerator DeathRoutine()
    {
        yield return new WaitForSeconds(2f);
        Destroy(gameObject);
    }
}
