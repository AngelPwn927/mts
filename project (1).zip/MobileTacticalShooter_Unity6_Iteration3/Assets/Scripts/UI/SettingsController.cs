using UnityEngine;
using UnityEngine.UI;

public class SettingsController : MonoBehaviour
{
    [SerializeField] private Slider sensitivitySlider;
    [SerializeField] private Toggle shadowsToggle;
    [SerializeField] private Toggle vibrationToggle;

    private const string SensitivityKey = "Sensitivity";
    private const string ShadowsKey = "Shadows";
    private const string VibrationKey = "Vibration";

    private void Start()
    {
        if (sensitivitySlider)
            sensitivitySlider.value =
                PlayerPrefs.GetFloat(SensitivityKey, 1f);

        if (shadowsToggle)
            shadowsToggle.isOn =
                PlayerPrefs.GetInt(ShadowsKey, 1) == 1;

        if (vibrationToggle)
            vibrationToggle.isOn =
                PlayerPrefs.GetInt(VibrationKey, 1) == 1;
    }

    public void SetSensitivity(float value)
    {
        PlayerPrefs.SetFloat(SensitivityKey, value);
    }

    public void SetShadows(bool value)
    {
        PlayerPrefs.SetInt(ShadowsKey, value ? 1 : 0);
        QualitySettings.shadows =
            value ? ShadowQuality.All : ShadowQuality.Disable;
    }

    public void SetVibration(bool value)
    {
        PlayerPrefs.SetInt(VibrationKey, value ? 1 : 0);
    }

    public void Save()
    {
        PlayerPrefs.Save();
    }
}
