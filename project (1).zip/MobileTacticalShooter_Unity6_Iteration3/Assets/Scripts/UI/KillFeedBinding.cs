using UnityEngine;

// Подписывает смерть владельца в KillFeed: "killer > victim".
public class KillFeedBinding : MonoBehaviour
{
    [SerializeField] private Health source;
    [SerializeField] private KillFeed feed;
    [SerializeField] private string displayName = "Bot";

    private void Awake()
    {
        if (!source) source = GetComponent<Health>();
        if (source) source.Died += Handle;
    }

    private void OnDestroy()
    {
        if (source) source.Died -= Handle;
    }

    private void Handle(DamageInfo info)
    {
        if (!feed) return;

        string killer = info.Attacker ? info.Attacker.name : "World";
        feed.AddKill(killer, displayName, false);
    }
}
