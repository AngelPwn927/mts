using UnityEngine;
using System;

public class Health : MonoBehaviour
{
    [SerializeField] private float maxHealth = 100f;

    public float Current { get; private set; }
    public float Max => maxHealth;
    public bool IsDead => Current <= 0f;

    public event Action<float, float> Changed;
    public event Action<DamageInfo> Died;

    private void Awake()
    {
        Current = maxHealth;
    }

    public void TakeDamage(
        float amount,
        GameObject attacker = null)
    {
        if (IsDead) return;

        Armor armor = GetComponent<Armor>();
        if (armor)
            amount = armor.Absorb(amount);

        Current = Mathf.Max(
            0f,
            Current - Mathf.Max(0f, amount));

        Changed?.Invoke(Current, maxHealth);

        if (Current <= 0f)
        {
            Died?.Invoke(
                new DamageInfo(
                    amount,
                    attacker,
                    gameObject));
        }
    }

    public void HealFull()
    {
        Current = maxHealth;
        Changed?.Invoke(Current, maxHealth);
    }
}

public readonly struct DamageInfo
{
    public readonly float Amount;
    public readonly GameObject Attacker;
    public readonly GameObject Victim;

    public DamageInfo(
        float amount,
        GameObject attacker,
        GameObject victim)
    {
        Amount = amount;
        Attacker = attacker;
        Victim = victim;
    }
}
