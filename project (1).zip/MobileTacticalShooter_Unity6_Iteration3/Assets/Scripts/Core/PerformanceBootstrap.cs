using UnityEngine;

public class PerformanceBootstrap : MonoBehaviour
{
    [SerializeField] private int targetFps = 60;

    private void Awake()
    {
        Application.targetFrameRate = targetFps;
        QualitySettings.vSyncCount = 0;
    }
}
