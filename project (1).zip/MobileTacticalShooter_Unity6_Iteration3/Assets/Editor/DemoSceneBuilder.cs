using UnityEngine;
using UnityEngine.AI;
using UnityEngine.UI;
using UnityEngine.Rendering;
using UnityEngine.EventSystems;
using UnityEditor;
using UnityEditor.SceneManagement;
using Unity.AI.Navigation;

// Генерирует полностью играбельную демо-сцену из кода:
// арена + NavMesh, игрок с оружием, 4 бота, мобильный HUD.
// Меню: TacticalShooter → Build Demo Scene
public static class DemoSceneBuilder
{
    private const string ScenePath = "Assets/Scenes/Demo.unity";
    private const string WeaponDataPath = "Assets/Data/AssaultRifle.asset";
    private const string GrenadePrefabPath = "Assets/Prefabs/Grenade.prefab";

    private class PlayerRig
    {
        public GameObject root;
        public Health health;
        public PlayerMovementAdvanced movement;
        public Weapon weapon;
        public GrenadeController grenade;
        public MobileInputHub hub;
        public PlayerRespawn respawn;
    }

    [MenuItem("TacticalShooter/Build Demo Scene")]
    public static void Build()
    {
        EditorSceneManager.NewScene(NewSceneSetup.EmptyScene, NewSceneMode.Single);

        EnsureFolder("Assets", "Scenes");
        EnsureFolder("Assets", "Data");
        EnsureFolder("Assets", "Prefabs");

        WeaponData data = EnsureWeaponData();
        GameObject grenadePrefab = EnsureGrenadePrefab();
        AudioClip shot = LoadClip("shot");
        AudioClip empty = LoadClip("empty");
        AudioClip step = LoadClip("footstep");

        GameObject systems = new GameObject("Systems");
        systems.AddComponent<PerformanceBootstrap>();

        CreateLighting();
        GameObject ground = CreateArena();

        PlayerRig rig = CreatePlayer(data, grenadePrefab, shot, empty, step);
        KillFeed feed = CreateUI(rig);
        CreateBots(data, shot, feed);

        // NavMesh печём в самом конце, когда вся статика расставлена
        NavMeshSurface surface = ground.AddComponent<NavMeshSurface>();
        surface.collectObjects = CollectObjects.All;
        surface.BuildNavMesh();

        EditorBuildSettings.scenes = new[]
        {
            new EditorBuildSettingsScene(ScenePath, true)
        };

        EditorSceneManager.SaveScene(EditorSceneManager.GetActiveScene(), ScenePath);
        AssetDatabase.SaveAssets();

        Debug.Log("<b>[TacticalShooter]</b> Демо-сцена собрана: " + ScenePath +
                  "\nСледующий шаг: TacticalShooter → Build Android APK");
    }

    // ------------------------------------------------------------------ ассеты

    private static WeaponData EnsureWeaponData()
    {
        WeaponData data = AssetDatabase.LoadAssetAtPath<WeaponData>(WeaponDataPath);
        if (data) return data;

        data = ScriptableObject.CreateInstance<WeaponData>();
        data.damage = 24f;
        data.fireRate = 9f;
        data.range = 120f;
        data.hitMask = ~0;
        data.headshotMultiplier = 2f;
        data.hipSpread = 2.5f;
        data.aimSpread = .6f;
        data.magazineSize = 30;
        data.reloadTime = 1.8f;
        data.recoilPitch = 1.1f;
        data.recoilYaw = .5f;

        AssetDatabase.CreateAsset(data, WeaponDataPath);
        return data;
    }

    private static GameObject EnsureGrenadePrefab()
    {
        GameObject prefab = AssetDatabase.LoadAssetAtPath<GameObject>(GrenadePrefabPath);
        if (prefab) return prefab;

        GameObject go = GameObject.CreatePrimitive(PrimitiveType.Sphere);
        go.name = "Grenade";
        go.transform.localScale = new Vector3(.22f, .22f, .22f);
        Paint(go, new Color(.15f, .3f, .16f));

        Rigidbody body = go.AddComponent<Rigidbody>();
        body.mass = .5f;

        ProjectileGrenade grenade = go.AddComponent<ProjectileGrenade>();
        SetField(grenade, "body", body);
        SetField(grenade, "fuse", 2.5f);
        SetField(grenade, "radius", 5f);
        SetField(grenade, "damage", 80f);
        SetField(grenade, "hitMask", ~0);

        prefab = PrefabUtility.SaveAsPrefabAsset(go, GrenadePrefabPath);
        Object.DestroyImmediate(go);
        return prefab;
    }

    private static AudioClip LoadClip(string name)
    {
        return AssetDatabase.LoadAssetAtPath<AudioClip>("Assets/Audio/" + name + ".wav");
    }

    // ------------------------------------------------------------------ мир

    private static void CreateLighting()
    {
        GameObject sun = new GameObject("Directional Light");
        Light light = sun.AddComponent<Light>();
        light.type = LightType.Directional;
        light.intensity = 1.1f;
        light.shadows = LightShadows.Soft;
        sun.transform.rotation = Quaternion.Euler(50f, -30f, 0f);

        RenderSettings.ambientMode = AmbientMode.Trilight;
        RenderSettings.ambientSkyColor = new Color(.55f, .6f, .7f);
        RenderSettings.ambientEquatorColor = new Color(.45f, .45f, .48f);
        RenderSettings.ambientGroundColor = new Color(.3f, .3f, .28f);
        RenderSettings.fog = true;
        RenderSettings.fogMode = FogMode.Exponential;
        RenderSettings.fogDensity = .012f;
        RenderSettings.fogColor = new Color(.52f, .58f, .66f);
    }

    private static GameObject CreateArena()
    {
        Color groundColor = new Color(.32f, .35f, .3f);
        Color wallColor = new Color(.45f, .44f, .42f);
        Color coverColor = new Color(.5f, .42f, .34f);

        GameObject ground = CreateBox("Ground", new Vector3(80f, 1f, 80f), new Vector3(0f, -.5f, 0f), groundColor);
        ground.isStatic = true;

        CreateBox("Wall_N", new Vector3(80f, 4f, 1f), new Vector3(0f, 2f, -40f), wallColor).isStatic = true;
        CreateBox("Wall_S", new Vector3(80f, 4f, 1f), new Vector3(0f, 2f, 40f), wallColor).isStatic = true;
        CreateBox("Wall_W", new Vector3(1f, 4f, 80f), new Vector3(-40f, 2f, 0f), wallColor).isStatic = true;
        CreateBox("Wall_E", new Vector3(1f, 4f, 80f), new Vector3(40f, 2f, 0f), wallColor).isStatic = true;

        Vector3[] covers =
        {
            new Vector3(-12f, 0f, -8f), new Vector3(10f, 0f, -14f),
            new Vector3(16f, 0f, 6f),  new Vector3(-8f, 0f, 12f),
            new Vector3(0f, 0f, -22f), new Vector3(-20f, 0f, 0f),
            new Vector3(22f, 0f, -2f), new Vector3(6f, 0f, 18f)
        };

        for (int i = 0; i < covers.Length; i++)
        {
            bool wide = i % 2 == 0;
            Vector3 size = wide
                ? new Vector3(3.5f, 1.6f, 1f)
                : new Vector3(1f, 1.6f, 3.5f);

            CreateBox("Cover_" + i, size, covers[i] + Vector3.up * .8f, coverColor)
                .isStatic = true;
        }

        return ground;
    }

    private static GameObject CreateBox(string name, Vector3 size, Vector3 position, Color color)
    {
        GameObject go = GameObject.CreatePrimitive(PrimitiveType.Cube);
        go.name = name;
        go.transform.position = position;
        go.transform.localScale = size;
        Paint(go, color);
        return go;
    }

    private static void Paint(GameObject go, Color color)
    {
        Shader shader = Shader.Find("Standard");
        if (!shader) shader = Shader.Find("Legacy Shaders/Diffuse");
        if (!shader) return;

        go.GetComponent<MeshRenderer>().sharedMaterial = new Material(shader) { color = color };
    }

    // ------------------------------------------------------------------ игрок

    private static PlayerRig CreatePlayer(
        WeaponData data, GameObject grenadePrefab,
        AudioClip shot, AudioClip empty, AudioClip step)
    {
        PlayerRig rig = new PlayerRig();

        GameObject player = new GameObject("Player");
        player.tag = "Player";
        rig.root = player;
        player.transform.position = new Vector3(0f, 1.05f, 14f);

        CharacterController cc = player.AddComponent<CharacterController>();
        cc.height = 1.8f;
        cc.radius = .35f;
        cc.center = new Vector3(0f, .9f, 0f);
        cc.slopeLimit = 45f;
        cc.stepOffset = .4f;

        rig.movement = player.AddComponent<PlayerMovementAdvanced>();
        SetField(rig.movement, "controller", cc);

        rig.health = player.AddComponent<Health>();
        player.AddComponent<Armor>();

        // Hitboxes: голова вынесена над капсулой CharacterController,
        // чтобы рейкасты в голову не перехватывались капсулой корня.
        AddHitbox(player.transform, "Hitbox_Body",
            typeof(CapsuleCollider), new Vector3(0f, .9f, 0f), new Vector3(.7f, 1.15f, .7f),
            rig.health, DamageableHitbox.HitZone.Body);
        AddHitbox(player.transform, "Hitbox_Head",
            typeof(SphereCollider), new Vector3(0f, 1.88f, 0f), new Vector3(.4f, .4f, .4f),
            rig.health, DamageableHitbox.HitZone.Head);
        AddHitbox(player.transform, "Hitbox_Legs",
            typeof(CapsuleCollider), new Vector3(0f, .35f, 0f), new Vector3(.56f, .6f, .56f),
            rig.health, DamageableHitbox.HitZone.Legs);

        // Camera rig: CameraRoot (pitch) → RecoilPivot (отдача) → Camera
        Transform camRoot = new GameObject("CameraRoot").transform;
        camRoot.SetParent(player.transform, false);
        camRoot.localPosition = new Vector3(0f, 1.62f, 0f);

        TouchLookController look = camRoot.gameObject.AddComponent<TouchLookController>();
        SetField(look, "body", player.transform);

        Transform recoilPivot = new GameObject("RecoilPivot").transform;
        recoilPivot.SetParent(camRoot, false);
        CameraRecoil camRecoil = recoilPivot.gameObject.AddComponent<CameraRecoil>();

        GameObject camGo = new GameObject("Main Camera");
        camGo.tag = "MainCamera";
        camGo.transform.SetParent(recoilPivot, false);

        Camera cam = camGo.AddComponent<Camera>();
        cam.nearClipPlane = .05f;
        cam.fieldOfView = 70f;
        cam.clearFlags = CameraClearFlags.SolidColor;
        cam.backgroundColor = new Color(.52f, .58f, .66f);
        camGo.AddComponent<AudioListener>();

        // Вид оружия от первого лица (без коллайдера, чтобы не ловить свои рейкасты)
        GameObject viewmodel = GameObject.CreatePrimitive(PrimitiveType.Cube);
        viewmodel.name = "ViewModel_Weapon";
        Object.DestroyImmediate(viewmodel.GetComponent<BoxCollider>());
        viewmodel.transform.SetParent(camGo.transform, false);
        viewmodel.transform.localPosition = new Vector3(.22f, -.2f, .5f);
        viewmodel.transform.localScale = new Vector3(.1f, .14f, .55f);
        Paint(viewmodel, new Color(.15f, .15f, .17f));

        AudioSource vmAudio = viewmodel.AddComponent<AudioSource>();
        vmAudio.spatialBlend = 0f;

        rig.weapon = viewmodel.AddComponent<Weapon>();
        SetField(rig.weapon, "data", data);
        SetField(rig.weapon, "playerCamera", cam);
        SetField(rig.weapon, "recoilPivot", viewmodel.transform);
        SetField(rig.weapon, "fireClip", shot);
        SetField(rig.weapon, "emptyClip", empty);
        SetField(rig.weapon, "audioSource", vmAudio);

        // Шаги
        AudioSource stepSource = player.AddComponent<AudioSource>();
        stepSource.spatialBlend = 0f;
        FootstepController footsteps = player.AddComponent<FootstepController>();
        SetField(footsteps, "controller", cc);
        SetField(footsteps, "source", stepSource);
        SetField(footsteps, "clips", new[] { step });

        // Гранаты
        rig.grenade = player.AddComponent<GrenadeController>();
        SetField(rig.grenade, "grenadePrefab", grenadePrefab);
        SetField(rig.grenade, "throwPoint", camGo.transform);

        // Ввод + респавн
        rig.hub = player.AddComponent<MobileInputHub>();
        SetField(rig.hub, "movement", rig.movement);
        SetField(rig.hub, "weapon", rig.weapon);
        SetField(rig.hub, "grenade", rig.grenade);
        SetField(rig.hub, "cameraRecoil", camRecoil);

        GameObject spawnPoint = new GameObject("SpawnPoint");
        spawnPoint.transform.position = new Vector3(0f, 1.05f, 14f);

        rig.respawn = player.AddComponent<PlayerRespawn>();
        SetField(rig.respawn, "controller", cc);
        SetField(rig.respawn, "spawnPoint", spawnPoint.transform);

        return rig;
    }

    // ------------------------------------------------------------------ боты

    private static void CreateBots(WeaponData data, AudioClip shot, KillFeed feed)
    {
        Vector3[] positions =
        {
            new Vector3(-12f, 0f, -10f),
            new Vector3(14f, 0f, -4f),
            new Vector3(0f, 0f, -24f),
            new Vector3(-18f, 0f, 8f)
        };

        for (int i = 0; i < positions.Length; i++)
            CreateBot(data, shot, feed, positions[i], "Bot_" + (i + 1));
    }

    private static void CreateBot(
        WeaponData data, AudioClip shot, KillFeed feed,
        Vector3 position, string name)
    {
        GameObject bot = new GameObject(name);
        bot.transform.position = position;

        NavMeshAgent agent = bot.AddComponent<NavMeshAgent>();
        agent.speed = 3.2f;
        agent.angularSpeed = 360f;
        agent.acceleration = 10f;
        agent.radius = .38f;
        agent.height = 1.8f;
        agent.stoppingDistance = 8f;

        Health health = bot.AddComponent<Health>();
        SetField(health, "maxHealth", 100f);

        // Визуал: капсула-тело + голова + ствол. Коллайдеры НЕ на корне,
        // иначе они перехватывают хедшоты до хитбоксов.
        GameObject body = GameObject.CreatePrimitive(PrimitiveType.Capsule);
        Object.DestroyImmediate(body.GetComponent<CapsuleCollider>());
        body.name = "Visual_Body";
        body.transform.SetParent(bot.transform, false);
        body.transform.localPosition = new Vector3(0f, .9f, 0f);
        body.transform.localScale = new Vector3(.7f, .9f, .7f);
        Paint(body, new Color(.75f, .25f, .2f));

        GameObject head = GameObject.CreatePrimitive(PrimitiveType.Sphere);
        Object.DestroyImmediate(head.GetComponent<SphereCollider>());
        head.name = "Visual_Head";
        head.transform.SetParent(bot.transform, false);
        head.transform.localPosition = new Vector3(0f, 1.65f, 0f);
        head.transform.localScale = new Vector3(.45f, .45f, .45f);
        Paint(head, new Color(.8f, .7f, .6f));

        GameObject gun = GameObject.CreatePrimitive(PrimitiveType.Cube);
        Object.DestroyImmediate(gun.GetComponent<BoxCollider>());
        gun.name = "Visual_Gun";
        gun.transform.SetParent(bot.transform, false);
        gun.transform.localPosition = new Vector3(.25f, 1.3f, .3f);
        gun.transform.localScale = new Vector3(.08f, .08f, .5f);
        Paint(gun, new Color(.12f, .12f, .14f));

        AddHitbox(bot.transform, "Hitbox_Body",
            typeof(CapsuleCollider), new Vector3(0f, .8f, 0f), new Vector3(.7f, 1.3f, .7f),
            health, DamageableHitbox.HitZone.Body);
        AddHitbox(bot.transform, "Hitbox_Head",
            typeof(SphereCollider), new Vector3(0f, 1.65f, 0f), new Vector3(.48f, .48f, .48f),
            health, DamageableHitbox.HitZone.Head);
        AddHitbox(bot.transform, "Hitbox_Legs",
            typeof(CapsuleCollider), new Vector3(0f, .28f, 0f), new Vector3(.6f, .55f, .6f),
            health, DamageableHitbox.HitZone.Legs);

        // Глаз-камера: выключена, нужна только как точка рейкастов оружия бота
        GameObject eye = new GameObject("Eye");
        eye.transform.SetParent(bot.transform, false);
        eye.transform.localPosition = new Vector3(0f, 1.6f, 0f);
        Camera eyeCam = eye.AddComponent<Camera>();
        eyeCam.enabled = false;

        AudioSource botAudio = gun.AddComponent<AudioSource>();
        botAudio.spatialBlend = 1f;

        Weapon botWeapon = gun.AddComponent<Weapon>();
        SetField(botWeapon, "data", data);
        SetField(botWeapon, "playerCamera", eyeCam);
        SetField(botWeapon, "fireClip", shot);
        SetField(botWeapon, "audioSource", botAudio);

        BotController controller = bot.AddComponent<BotController>();
        SetField(controller, "agent", agent);
        SetField(controller, "weapon", botWeapon);
        SetField(controller, "eye", eye.transform);
        SetField(controller, "health", health);

        KillFeedBinding binding = bot.AddComponent<KillFeedBinding>();
        SetField(binding, "source", health);
        SetField(binding, "feed", feed);
        SetField(binding, "displayName", name);
    }

    private static void AddHitbox(
        Transform parent, string name, System.Type colliderType,
        Vector3 center, Vector3 size, Health owner, DamageableHitbox.HitZone zone)
    {
        GameObject go = new GameObject(name);
        go.transform.SetParent(parent, false);
        go.transform.localPosition = center;

        if (colliderType == typeof(CapsuleCollider))
        {
            CapsuleCollider capsule = go.AddComponent<CapsuleCollider>();
            capsule.radius = size.x * .5f;
            capsule.height = size.y;
            capsule.direction = 1;
        }
        else if (colliderType == typeof(SphereCollider))
        {
            SphereCollider sphere = go.AddComponent<SphereCollider>();
            sphere.radius = size.x * .5f;
        }

        DamageableHitbox hitbox = go.AddComponent<DamageableHitbox>();
        SetField(hitbox, "owner", owner);
        SetField(hitbox, "zone", (int)zone);
    }

    // ------------------------------------------------------------------ UI

    private static KillFeed CreateUI(PlayerRig rig)
    {
        GameObject canvasGo = new GameObject("Canvas");
        Canvas canvas = canvasGo.AddComponent<Canvas>();
        canvas.renderMode = Canvas.RenderMode.ScreenSpaceOverlay;

        CanvasScaler scaler = canvasGo.AddComponent<CanvasScaler>();
        scaler.uiScaleMode = CanvasScaler.ScaleMode.ScaleWithScreenSize;
        scaler.referenceResolution = new Vector2(1920f, 1080f);
        scaler.matchWidthOrHeight = .5f;

        canvasGo.AddComponent<GraphicRaycaster>();

        GameObject eventSystem = new GameObject("EventSystem");
        eventSystem.AddComponent<EventSystem>();
        eventSystem.AddComponent<StandaloneInputModule>();

        // Прицел
        Image crosshair = Panel(canvasGo.transform, "Crosshair", new Color(1f, 1f, 1f, .8f));
        Anchor(crosshair.rectTransform, new Vector2(.5f, .5f), Vector2.zero, new Vector2(14f, 14f));
        crosshair.raycastTarget = false;

        // HP
        Image hpBackground = Panel(canvasGo.transform, "HP_Background", new Color(0f, 0f, 0f, .45f));
        Anchor(hpBackground.rectTransform, new Vector2(.5f, 0f), new Vector2(0f, 90f), new Vector2(560f, 46f));

        Image hpFill = Panel(hpBackground.transform, "HP_Fill", new Color(.2f, .85f, .3f, .9f));
        Anchor(hpFill.rectTransform, new Vector2(.5f, .5f), Vector2.zero, new Vector2(548f, 38f));
        hpFill.type = Image.Type.Filled;
        hpFill.fillMethod = Image.FillMethod.Horizontal;
        hpFill.fillAmount = 1f;
        hpFill.raycastTarget = false;

        Text hpLabel = Label(hpBackground.transform, "HP_Text", "100", 26,
            TextAnchor.MiddleCenter,
            anchor: new Vector2(.5f, .5f), position: new Vector2(-270f, 0f), size: new Vector2(80f, 40f));

        // Патроны
        Text ammo = Label(canvasGo.transform, "Ammo", "30 / 90", 40,
            TextAnchor.MiddleRight,
            anchor: new Vector2(1f, 1f), position: new Vector2(-50f, -60f), size: new Vector2(400f, 60f));

        // Kill feed
        Text feedLabel = Label(canvasGo.transform, "KillFeed", "", 28,
            TextAnchor.UpperRight, color: new Color(1f, .9f, .7f),
            anchor: new Vector2(1f, 1f), position: new Vector2(-50f, -110f), size: new Vector2(700f, 320f));
        KillFeed feed = feedLabel.gameObject.AddComponent<KillFeed>();
        SetField(feed, "text", feedLabel);

        // Джойстик (слева внизу)
        Image joystickBackground = Panel(canvasGo.transform, "Joystick", new Color(1f, 1f, 1f, .1f));
        Anchor(joystickBackground.rectTransform, new Vector2(0f, 0f), new Vector2(220f, 220f), new Vector2(280f, 280f));

        Image handle = Panel(joystickBackground.transform, "Handle", new Color(1f, 1f, 1f, .35f));
        Anchor(handle.rectTransform, new Vector2(.5f, .5f), Vector2.zero, new Vector2(120f, 120f));

        VirtualJoystick joystick = joystickBackground.gameObject.AddComponent<VirtualJoystick>();
        SetField(joystick, "background", joystickBackground.rectTransform);
        SetField(joystick, "handle", handle.rectTransform);
        SetField(joystick, "handleRange", 80f);
        SetField(rig.movement, "joystick", joystick);

        // Панель настроек (создаём ДО кнопки, которая её открывает)
        GameObject settingsPanel = CreateSettingsPanel(canvasGo.transform);

        // Кнопки (справа внизу)
        Button fire = Button(canvasGo.transform, "Btn_Fire", "FIRE",
            new Vector2(1f, 0f), new Vector2(-170f, 190f), new Vector2(230f, 230f));
        AddHold(fire, () => rig.hub.SetFiring(true), () => rig.hub.SetFiring(false));

        Button(canvasGo.transform, "Btn_Reload", "R",
            new Vector2(1f, 0f), new Vector2(-170f, 370f), new Vector2(110f, 110f),
            () => rig.hub.Reload());

        Button(canvasGo.transform, "Btn_Grenade", "GRN",
            new Vector2(1f, 0f), new Vector2(-320f, 190f), new Vector2(110f, 110f),
            () => rig.hub.ThrowGrenade());

        Button sprint = Button(canvasGo.transform, "Btn_Sprint", "SPR",
            new Vector2(1f, 0f), new Vector2(-170f, 40f), new Vector2(110f, 110f));
        AddHold(sprint, () => rig.hub.SetSprint(true), () => rig.hub.SetSprint(false));

        Button(canvasGo.transform, "Btn_Jump", "JMP",
            new Vector2(1f, 0f), new Vector2(-320f, 340f), new Vector2(110f, 110f),
            () => rig.hub.Jump());

        Button(canvasGo.transform, "Btn_Crouch", "CRCH",
            new Vector2(1f, 0f), new Vector2(-440f, 190f), new Vector2(110f, 110f),
            () => rig.hub.ToggleCrouch());

        // Кнопка настроек слева вверху
        Button(canvasGo.transform, "Btn_Settings", "SET",
            new Vector2(0f, 1f), new Vector2(70f, -70f), new Vector2(110f, 110f),
            () => settingsPanel.SetActive(true));

        // Панель смерти (после HUD: кнопка респавна вызывает hud.OnRespawnClicked)
        HUDController hud = canvasGo.AddComponent<HUDController>();
        GameObject deathPanel = CreateDeathPanel(canvasGo.transform, hud);

        SetField(hud, "playerHealth", rig.health);
        SetField(hud, "healthFill", hpFill);
        SetField(hud, "healthText", hpLabel);
        SetField(hud, "ammoText", ammo);
        SetField(hud, "deathPanel", deathPanel);
        SetField(hud, "respawn", rig.respawn);
        SetField(hud, "inputHub", rig.hub);
        SetField(hud, "movement", rig.movement);
        SetField(hud, "weapon", rig.weapon);

        return feed;
    }

    private static GameObject CreateSettingsPanel(Transform canvas)
    {
        Image panelImage = Panel(canvas, "SettingsPanel", new Color(0f, 0f, 0f, .78f));
        Stretch(panelImage.rectTransform);
        GameObject panel = panelImage.gameObject;
        panel.SetActive(false);

        Label(panel.transform, "Title", "НАСТРОЙКИ", 56, TextAnchor.MiddleCenter,
            anchor: new Vector2(.5f, 1f), position: new Vector2(0f, -120f), size: new Vector2(800f, 90f));

        // Чувствительность
        Label(panel.transform, "SensLabel", "Чувствительность", 34, TextAnchor.MiddleLeft,
            anchor: new Vector2(.5f, .5f), position: new Vector2(-350f, 90f), size: new Vector2(560f, 50f));

        Image sliderBackground = Panel(panel.transform, "SensSlider", new Color(1f, 1f, 1f, .15f));
        Anchor(sliderBackground.rectTransform, new Vector2(.5f, .5f), new Vector2(250f, 90f), new Vector2(560f, 44f));
        Slider slider = sliderBackground.gameObject.AddComponent<Slider>();
        slider.targetGraphic = sliderBackground;

        Image sliderFill = Panel(sliderBackground.transform, "Fill", new Color(.3f, .6f, 1f, .8f));
        RectTransform fillArea = sliderFill.rectTransform;
        fillArea.anchorMin = new Vector2(0f, 0f);
        fillArea.anchorMax = new Vector2(1f, 1f);
        fillArea.offsetMin = new Vector2(6f, 6f);
        fillArea.offsetMax = new Vector2(-6f, -6f);
        slider.fillRect = fillArea;

        Image handleImage = Panel(sliderBackground.transform, "Handle", Color.white);
        Anchor(handleImage.rectTransform, new Vector2(.5f, .5f), Vector2.zero, new Vector2(26f, 52f));
        slider.handleRect = handleImage.rectTransform;
        slider.direction = Slider.Direction.LeftToRight;
        slider.minValue = .2f;
        slider.maxValue = 3f;

        // Тени
        Toggle shadowsToggle = CreateToggle(panel.transform, "ShadowsToggle",
            new Vector2(-350f, 0f), "Тени");
        // Вибрация
        Toggle vibrationToggle = CreateToggle(panel.transform, "VibrationToggle",
            new Vector2(-350f, -110f), "Вибрация");

        SettingsController settings = panel.AddComponent<SettingsController>();
        SetField(settings, "sensitivitySlider", slider);
        SetField(settings, "shadowsToggle", shadowsToggle);
        SetField(settings, "vibrationToggle", vibrationToggle);

        slider.onValueChanged.AddListener(settings.SetSensitivity);
        shadowsToggle.onValueChanged.AddListener(settings.SetShadows);
        vibrationToggle.onValueChanged.AddListener(settings.SetVibration);

        Button(panel.transform, "Btn_Save", "СОХРАНИТЬ И ЗАКРЫТЬ",
            new Vector2(.5f, .5f), new Vector2(0f, -220f), new Vector2(560f, 90f),
            () =>
            {
                settings.Save();
                panel.SetActive(false);
            });

        return panel;
    }

    private static Toggle CreateToggle(Transform panel, string name, Vector2 position, string caption)
    {
        Image background = Panel(panel, name, new Color(1f, 1f, 1f, .15f));
        Anchor(background.rectTransform, new Vector2(.5f, .5f), position, new Vector2(56f, 56f));
        Toggle toggle = background.gameObject.AddComponent<Toggle>();
        toggle.targetGraphic = background;

        Image checkmark = Panel(background.transform, "Checkmark", new Color(.2f, .85f, .3f, .95f));
        Anchor(checkmark.rectTransform, new Vector2(.5f, .5f), Vector2.zero, new Vector2(40f, 40f));
        toggle.graphic = checkmark;

        Label(background.transform, "Caption", caption, 34, TextAnchor.MiddleLeft,
            anchor: new Vector2(0f, .5f), position: new Vector2(48f, 0f), size: new Vector2(460f, 50f));

        toggle.isOn = true;
        return toggle;
    }

    private static GameObject CreateDeathPanel(Transform canvas, HUDController hud)
    {
        Image panelImage = Panel(canvas, "DeathPanel", new Color(.35f, 0f, 0f, .8f));
        Stretch(panelImage.rectTransform);
        GameObject panel = panelImage.gameObject;
        panel.SetActive(false);

        Label(panel.transform, "YouDied", "ВЫ УБИТЫ", 90, TextAnchor.MiddleCenter,
            anchor: new Vector2(.5f, .5f), position: new Vector2(0f, 80f), size: new Vector2(900f, 140f));

        Button(panel.transform, "Btn_Respawn", "ВОЗРОДИТЬСЯ",
            new Vector2(.5f, .5f), new Vector2(0f, -110f), new Vector2(520f, 100f),
            hud.OnRespawnClicked);

        return panel;
    }

    // ------------------------------------------------------------------ утилиты UI

    private static Image Panel(Transform parent, string name, Color color)
    {
        GameObject go = new GameObject(name, typeof(RectTransform));
        go.transform.SetParent(parent, false);
        Image image = go.AddComponent<Image>();
        image.color = color;
        return image;
    }

    private static void Anchor(RectTransform rt, Vector2 anchor, Vector2 position, Vector2 size)
    {
        rt.anchorMin = anchor;
        rt.anchorMax = anchor;
        rt.pivot = new Vector2(.5f, .5f);
        rt.anchoredPosition = position;
        rt.sizeDelta = size;
    }

    private static void Stretch(RectTransform rt)
    {
        rt.anchorMin = Vector2.zero;
        rt.anchorMax = Vector2.one;
        rt.pivot = new Vector2(.5f, .5f);
        rt.anchoredPosition = Vector2.zero;
        rt.sizeDelta = Vector2.zero;
    }

    private static Text Label(
        Transform parent, string name, string text, int fontSize,
        TextAnchor alignment, Color? color = null,
        Vector2? anchor = null, Vector2? position = null, Vector2? size = null)
    {
        GameObject go = new GameObject(name, typeof(RectTransform));
        go.transform.SetParent(parent, false);

        Text label = go.AddComponent<Text>();
        label.text = text;
        label.fontSize = fontSize;
        label.alignment = alignment;
        label.color = color ?? Color.white;
        label.raycastTarget = false;
        label.font = UIFont();

        Anchor(label.rectTransform,
            anchor ?? new Vector2(.5f, .5f),
            position ?? Vector2.zero,
            size ?? new Vector2(300f, 60f));

        return label;
    }

    private static Font UIFont()
    {
        Font f = Resources.GetBuiltinResource<Font>("LegacyRuntime.ttf");
        if (f == null) f = Resources.GetBuiltinResource<Font>("Arial.ttf");
        return f;
    }

    private static Button Button(
        Transform parent, string name, string caption,
        Vector2 anchor, Vector2 position, Vector2 size,
        System.Action onClick = null)
    {
        Image image = Panel(parent, name, new Color(1f, 1f, 1f, .18f));
        Anchor(image.rectTransform, anchor, position, size);

        Label(image.transform, "Text", caption, 36, TextAnchor.MiddleCenter);

        Button button = image.gameObject.AddComponent<Button>();
        button.targetGraphic = image;

        if (onClick != null)
            button.onClick.AddListener(() => onClick());

        return button;
    }

    private static void AddHold(Button button, System.Action onPress, System.Action onRelease)
    {
        EventTrigger trigger = button.gameObject.AddComponent<EventTrigger>();

        EventTrigger.Entry down = new EventTrigger.Entry { eventID = EventTriggerType.PointerDown };
        down.callback.AddListener(_ => onPress());
        trigger.triggers.Add(down);

        EventTrigger.Entry up = new EventTrigger.Entry { eventID = EventTriggerType.PointerUp };
        up.callback.AddListener(_ => onRelease());
        trigger.triggers.Add(up);
    }

    // ------------------------------------------------------------------ утилиты ассетов

    private static void EnsureFolder(string parent, string name)
    {
        if (!AssetDatabase.IsValidFolder(parent + "/" + name))
            AssetDatabase.CreateFolder(parent, name);
    }

    private static void SetField(Object target, string field, object value)
    {
        SerializedObject so = new SerializedObject(target);
        SerializedProperty prop = so.FindProperty(field);

        if (prop == null)
        {
            Debug.LogError($"[TacticalShooter] Поле '{field}' не найдено на {target.GetType().Name}");
            return;
        }

        if (value == null)
        {
            prop.objectReferenceValue = null;
        }
        else if (value is Object[])
        {
            Object[] array = (Object[])value;
            prop.arraySize = array.Length;
            for (int i = 0; i < array.Length; i++)
                prop.GetArrayElementAtIndex(i).objectReferenceValue = array[i];
        }
        else if (value is Object)
        {
            prop.objectReferenceValue = (Object)value;
        }
        else if (value is float)
        {
            prop.floatValue = (float)value;
        }
        else if (value is int)
        {
            prop.intValue = (int)value;
        }
        else if (value is bool)
        {
            prop.boolValue = (bool)value;
        }
        else if (value is string)
        {
            prop.stringValue = (string)value;
        }
        else
        {
            Debug.LogError($"[TacticalShooter] Не поддерживаемый тип поля '{field}': {value.GetType().Name}");
        }

        so.ApplyModifiedProperties();
    }
}
