using System.IO;
using UnityEditor;
using UnityEditor.Build.Reporting;
using UnityEngine;

// Меню: TacticalShooter → Build Android APK
// CLI:  unity-editor -quit -batchmode -projectPath <путь> -executeMethod BuildAndroid.BuildFromCli
public static class BuildAndroid
{
    private const string OutputPath = "Builds/MobileTacticalShooter.apk";
    private const string ScenePath = "Assets/Scenes/Demo.unity";

    [MenuItem("TacticalShooter/Build Android APK")]
    public static void BuildFromMenu() => Build();

    // Точка входа для CI / командной строки (без -nographics!)
    public static void BuildFromCli()
    {
        bool ok = Build();
        EditorApplication.Exit(ok ? 0 : 1);
    }

    private static bool Build()
    {
        if (!File.Exists(ScenePath))
        {
            Debug.Log("[TacticalShooter] Сцена не найдена — генерирую автоматически...");
            DemoSceneBuilder.Build();
        }

        EditorUserBuildSettings.SwitchActiveBuildTarget(BuildTarget.Android);

        PlayerSettings.companyName = "Prototype";
        PlayerSettings.productName = "Mobile Tactical Shooter";
        PlayerSettings.applicationIdentifier = "com.prototype.mobiletacticalshooter";
        PlayerSettings.statusBarHidden = true;

#if UNITY_ANDROID
        PlayerSettings.Android.minSdkVersion = AndroidSdkVersions.AndroidApiLevel24;
        PlayerSettings.targetArchitectures = AndroidArchitecture.ARMv7 | AndroidArchitecture.ARM64;
        PlayerSettings.SetScriptingBackend(NamedBuildTarget.Android, ScriptingImplementation.IL2CPP);
#endif

        BuildReport report = BuildPipeline.BuildPlayer(
            new[] { ScenePath },
            OutputPath,
            BuildTarget.Android,
            BuildOptions.None);

        if (report.summary.result == BuildResult.Succeeded)
        {
            long mb = report.summary.totalSize / (1024 * 1024);
            Debug.Log($"<b>[TacticalShooter]</b> APK собран: {OutputPath} ({mb} MB)");
            EditorUtility.RevealInFinder(OutputPath);
            return true;
        }

        Debug.LogError("[TacticalShooter] Сборка не удалась: " + report.summary.result);
        return false;
    }
}
