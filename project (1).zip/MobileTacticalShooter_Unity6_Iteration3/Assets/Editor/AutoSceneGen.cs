using UnityEditor;
using UnityEngine;

// Автоматически создаёт демо-сцену при открытии проекта (в т.ч. в batch-режиме CI),
// если её ещё нет. Это позволяет собирать APK без ручного пункта меню.
[InitializeOnLoad]
public static class AutoSceneGen
{
    static AutoSceneGen()
    {
        if (EditorApplication.isPlayingOrWillChangePlaymode) return;
        if (System.IO.File.Exists("Assets/Scenes/Demo.unity")) return;

        Debug.Log("[TacticalShooter] Сцена не найдена — генерирую автоматически...");
        try
        {
            DemoSceneBuilder.Build();
        }
        catch (System.Exception e)
        {
            Debug.LogError("[TacticalShooter] Ошибка генерации сцены: " + e);
            throw;
        }
    }
}
