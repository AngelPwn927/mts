# Mobile Tactical Shooter — готовый к сборке Unity-проект (Iteration 3)

Это восстановленный из архива `MobileTacticalShooter_Unity6_Iteration3.zip` **полный Unity-проект**,
доведённый до состояния «открыл → собрал APK».

---

## ⚠️ Почему нельзя было собрать APK «просто так»

Исходный архив содержал **только C#-скрипты** (15 файлов): ни `ProjectSettings`, ни
`Packages/manifest.json`, ни сцен, ни префабов. Кроме того, в архиве **отсутствовали два класса**,
на которые код ссылался:

- `WeaponData` — ScriptableObject-конфиг оружия (`Weapon.cs` не компилировался);
- `VirtualJoystick` — виртуальный джойстик (`PlayerMovementAdvanced.cs` не компилировался).

Сам APK собирается только Unity-редактором (Unity 6.3 LTS + Android Build Support + SDK/NDK),
поэтому без редактора сборка невозможна в принципе.

## ✅ Что добавлено, чтобы проект собрался

| Файл | Назначение |
|---|---|
| `Assets/Scripts/Combat/WeaponData.cs` | **восстановлен** — конфиг оружия |
| `Assets/Scripts/Player/VirtualJoystick.cs` | **восстановлен** — UGUI-джойстик |
| `Assets/Scripts/Player/TouchLookController.cs` | обзор свайпом (правая часть экрана) |
| `Assets/Scripts/Player/MobileInputHub.cs` | кнопки: огонь/перезарядка/граната/прыжок/спринт/присед |
| `Assets/Scripts/Player/PlayerRespawn.cs` | респавн игрока |
| `Assets/Scripts/UI/HUDController.cs` | HP-бар, патроны, панель смерти |
| `Assets/Scripts/UI/KillFeedBinding.cs` | смерти ботов → kill feed |
| `Assets/Editor/DemoSceneBuilder.cs` | **генератор демо-сцены одним пунктом меню** |
| `Assets/Editor/BuildAndroid.cs` | сборка APK одним пунктом меню / из CLI |
| `Assets/Audio/*.wav` | процедурные звуки: выстрел, пустой магазин, шаги |
| `Packages/manifest.json` | пакеты: uGUI 2.0 (TMP), AI Navigation, Android Logcat |
| `ProjectSettings/ProjectVersion.txt` | Unity **6000.3.0f1** |

Весь код проверен на компиляцию (25 файлов, 0 ошибок).

---

## 🛠 Сборка APK — пошагово

### Шаг 0. Установить Unity (один раз)

1. Установи [Unity Hub](https://unity.com/download).
2. В Hub → **Installs → Install Editor → Unity 6.3 LTS** (6000.3.x).
3. При установке отметь галочки:
   - **Android Build Support**
   - ✅ OpenJDK
   - ✅ Android SDK & NDK Tools
4. Лицензия: Personal (бесплатная) — Hub предложит активировать при первом запуске.

### Шаг 1. Открыть проект

Unity Hub → **Add** → выбери папку `MobileTacticalShooter_Unity6_Iteration3` → открыть.
Дождись импорта (первый раз несколько минут).

### Шаг 2. Сгенерировать сцену

Меню вверху редактора: **TacticalShooter → Build Demo Scene**

Скрипт сам создаст и сохранит `Assets/Scenes/Demo.unity`:
- арену 80×80 со стенами и укрытиями + запечённый NavMesh;
- игрока (CharacterController, оружие, гранаты, камера с отдачей);
- 4 ботов (NavMesh + зрение/погоня/атака/стрейф, hitboxes Body/Head/Legs);
- мобильный HUD: джойстик, кнопки, HP, патроны, kill feed, настройки, экран смерти;
- ассет `WeaponData` и префаб гранаты (создаются автоматически).

### Шаг 3. Собрать APK

Меню: **TacticalShooter → Build Android APK**

Готовый файл появится в `<проект>/Builds/MobileTacticalShooter.apk`.

> Первая сборка долгая (10–20 мин): Gradle качает зависимости, IL2CPP компилирует.
> Последующие — быстрее. Нужно ~10 ГБ свободного места на диске.

### Альтернатива: вручную

`File → Build Settings → Android → Switch Platform` → `Add Open Scenes` → `Build`.

### Альтернатива: командная строка (CI)

```bash
# -nographics НЕ использовать — сломает компиляцию шейдеров
"<путь к Unity>" -batchmode -quit \
  -projectPath "<путь к проекту>" \
  -executeMethod BuildAndroid.BuildFromCli \
  -logFile build.log
```

---

## 🎮 Управление (на телефоне)

| Действие | Как |
|---|---|
| Движение | джойстик слева |
| Обзор | свайп по правой части экрана |
| Стрельба | удержание FIRE (автоогонь) |
| Перезарядка | R |
| Граната | GRN |
| Прыжок / спринт / присед | JMP / SPR (удерживать) / CRCH |
| Настройки (чувствительность, тени, вибрация) | SET слева вверху |

В редакторе для теста: ПКМ-движение мыши = обзор, FIRE — стрельба.

## 🔧 Если что-то пошло не так

- **«No Android module loaded»** — доустанови Android Build Support через Unity Hub → Installs → Add modules.
- **TMP-текст розовыми квадратами** — `Window → TextMeshPro → Import TMP Essential Resources`.
- **Ошибка лицензии в CLI** — сначала один раз открой проект в редакторе (активируется лицензия).
- **Смена версии Unity** — правь первую строку `ProjectSettings/ProjectVersion.txt` или открой через Hub («Upgrade»).
- Для Google Play нужен `.aab`: в Build Settings поставь *Build App Bundle (Google Play)*.

## 📌 Известные упрощения прототипа

- Боты могут ранить друг друга (нет дружественного огня-фильтра) — заложено в исходных скриптах Iteration 3.
- Smoke-граната не влияет на зрение ИИ (в README оригинала это помечено как «позже»).
- Нет адаптивного качества/LOD/pooling — см. «Важное ограничение» в `README_RU.md`.
- Это offline-прототип: networking не входит в Iteration 3.
