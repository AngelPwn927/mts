# Mobile Tactical Shooter — Iteration 3

Следующий слой оригинального мобильного tactical FPS-прототипа.

Добавлено:
- hitboxes Body/Head/Legs;
- headshot multiplier;
- armor;
- grenade;
- smoke grenade base;
- advanced player acceleration;
- camera recoil component;
- footsteps;
- improved AI vision cone;
- investigate last known position;
- AI strafing;
- kill feed;
- settings;
- target FPS bootstrap;
- weapon audio/empty magazine;
- улучшенная структура combat.

## Hitboxes

На Player/Bot:
Body collider -> DamageableHitbox Body
Head collider -> DamageableHitbox Head + Tag Head
Leg collider -> DamageableHitbox Legs

Все hitboxes должны ссылаться на общий Health.

## Grenades

GrenadeController:
throwPoint = child Camera/ViewModel.
ProjectileGrenade имеет Rigidbody.

SmokeGrenade можно разместить как отдельный prefab.
Для полноценного smoke gameplay позже нужен отдельный vision-blocking system:
AI должен учитывать smoke volumes, а renderer — использовать оптимизированный particle/VFX.

## Android

Для production обязательно:
- реальные Android device profiles;
- CPU/GPU profiling;
- adaptive quality;
- texture compression;
- ASTC/ETC2 в зависимости от device tier;
- LOD;
- occlusion;
- baked lighting;
- SRP Batcher;
- pooling.

## Важное ограничение текущей версии

Это всё ещё offline prototype. Для игры уровня коммерческого online FPS следующим крупным этапом является networking:
- authoritative server;
- client prediction;
- interpolation;
- lag compensation;
- server-side hit validation;
- replication;
- matchmaking;
- lobby;
- reconnect;
- anti-cheat.

Также нужны полноценные карты, модели, анимации, UI/UX и backend.
