using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class HUDController : MonoBehaviour
{
    [SerializeField] private Health playerHealth;
    [SerializeField] private Image healthFill;
    [SerializeField] private TMP_Text healthText;
    [SerializeField] private TMP_Text ammoText;
    [SerializeField] private GameObject deathPanel;
    [SerializeField] private PlayerRespawn respawn;
    [SerializeField] private MobileInputHub inputHub;
    [SerializeField] private PlayerMovementAdvanced movement;
    [SerializeField] private Weapon weapon;

    private void Start()
    {
        if (playerHealth)
        {
            playerHealth.Changed += OnHealthChanged;
            playerHealth.Died += OnDied;
            OnHealthChanged(playerHealth.Current, playerHealth.Max);
        }

        if (deathPanel)
            deathPanel.SetActive(false);
    }

    private void OnDestroy()
    {
        if (playerHealth)
        {
            playerHealth.Changed -= OnHealthChanged;
            playerHealth.Died -= OnDied;
        }
    }

    private void Update()
    {
        if (weapon && ammoText)
            ammoText.text = $"{weapon.Ammo} / {weapon.ReserveAmmo}";
    }

    private void OnHealthChanged(float current, float max)
    {
        float ratio = max > 0f ? current / max : 0f;

        if (healthFill)
            healthFill.fillAmount = ratio;

        if (healthText)
            healthText.text = Mathf.CeilToInt(current).ToString();
    }

    private void OnDied(DamageInfo info)
    {
        if (deathPanel) deathPanel.SetActive(true);
        if (inputHub) inputHub.enabled = false;
        if (movement) movement.enabled = false;
        if (weapon) weapon.enabled = false;
    }

    // Кнопка RESPAWN на панели смерти
    public void OnRespawnClicked()
    {
        if (respawn) respawn.TeleportToSpawn();
        if (playerHealth) playerHealth.HealFull();
        if (inputHub) inputHub.enabled = true;
        if (movement) movement.enabled = true;
        if (weapon) weapon.enabled = true;
        if (deathPanel) deathPanel.SetActive(false);
    }
}
