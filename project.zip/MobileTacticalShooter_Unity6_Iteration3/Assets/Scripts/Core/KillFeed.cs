using UnityEngine;
using TMPro;
using System.Collections;
using System.Collections.Generic;

public class KillFeed : MonoBehaviour
{
    [SerializeField] private TMP_Text text;
    [SerializeField] private int maxLines = 5;
    [SerializeField] private float lineLifetime = 5f;

    private readonly Queue<string> lines = new();

    public void AddKill(string killer, string victim, bool headshot)
    {
        string suffix = headshot ? "  [HEAD]" : "";
        lines.Enqueue($"{killer}  >  {victim}{suffix}");

        while (lines.Count > maxLines)
            lines.Dequeue();

        Refresh();
        StartCoroutine(ClearAfter(lineLifetime));
    }

    private IEnumerator ClearAfter(float seconds)
    {
        yield return new WaitForSeconds(seconds);
        if (lines.Count > 0)
        {
            lines.Dequeue();
            Refresh();
        }
    }

    private void Refresh()
    {
        if (text)
            text.text = string.Join("\n", lines);
    }
}
